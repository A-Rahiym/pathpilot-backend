import React, { useState, useRef } from "react";
import StyledButton from "@integratedComponents/StyledButton";

import { ParseIntentRequest } from "./intent_pb.js";
import { IntentService } from "./intent_pb_service.js";

import "./style.css";

/**
 * Main UI component for the Intent Parsing Service
 *
 * @param {Object} props
 * @param {Object} props.serviceClient gRPC service client provided by the platform
 * @param {boolean} props.isComplete Whether the service execution is complete
 */
const ServiceUI = ({ serviceClient, isComplete }) => {
  const [output, setOutput] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showOutput, setShowOutput] = useState(false);
  const [text, setText] = useState("");
  const textareaRef = useRef(null);

  const isAllowedToRun = () => !!text.trim();

  const onActionEnd = (response) => {
    console.log("gRPC Response:", response);
    console.log("Status:", response.status);
    console.log("Message:", response.message);

    setLoading(false);
    setShowOutput(true);

    if (response.status !== 0) {
      setOutput({ error: `Error ${response.status}: ${response.statusMessage}` });
      return;
    }

    if (!response.message) {
      setOutput({ error: "Server returned an empty response." });
      return;
    }

    setOutput(response);
  };

  const submitAction = () => {
    if (!isAllowedToRun()) return;

    try {
      setLoading(true);
      setShowOutput(false);
      setOutput(null);

      const request = new ParseIntentRequest();
      request.setTranscribedText(text.trim());

      console.log("Sending request:", request.toObject());

      serviceClient.unary(IntentService.ParseIntent, {
        request,
        preventCloseServiceOnEnd: false,
        onEnd: onActionEnd,
      });
    } catch (err) {
      console.error("Client error:", err);
      setOutput({ error: `Client error: ${err.message}` });
      setLoading(false);
      setShowOutput(true);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      if (isAllowedToRun()) submitAction();
    }
  };

  const renderResults = (data) => {
    const msg = data.message;
    if (!msg) return <p style={{ color: "var(--text-muted)", fontSize: 14 }}>No response received.</p>;

    const intent       = msg.getIntent?.()       || "—";
    const destination  = msg.getDestination?.()  || "—";
    const category     = msg.getCategory?.()     || "—";
    const confidence   = msg.getConfidence?.()   ?? null;
    const originalText = msg.getOriginalText?.() || "—";
    const timestamp    = msg.getTimestamp?.()    || "—";

    const confidencePct = confidence != null ? Math.round(confidence * 100) : null;

    return (
      <div className="results-grid">
        <div className="result-item">
          <div className="result-label">Intent</div>
          <div className="result-value">{intent}</div>
        </div>

        <div className="result-item">
          <div className="result-label">Destination</div>
          <div className="result-value">{destination}</div>
        </div>

        <div className="result-item">
          <div className="result-label">Category</div>
          <div className="result-value">{category}</div>
        </div>

        <div className="result-item">
          <div className="result-label">Confidence</div>
          <div className="result-value">
            {confidencePct != null ? `${confidencePct}%` : "—"}
          </div>
          {confidencePct != null && (
            <div className="confidence-bar-track">
              <div className="confidence-bar-fill" style={{ width: `${confidencePct}%` }} />
            </div>
          )}
        </div>

        <div className="result-item full">
          <div className="result-label">Original Text</div>
          <div className="result-value mono">{originalText}</div>
        </div>

        <div className="result-item full">
          <div className="result-label">Timestamp</div>
          <div className="result-value mono">{timestamp}</div>
        </div>
      </div>
    );
  };

  return (
    <div className="service-container">
      <div className="service-header">
        <h1 className="main-title">🧭 PathPilot Intent Parser</h1>
        <p className="subtitle">
          Enter transcribed text — the AI will extract intent, destination, category, and confidence.
        </p>
      </div>

      {/* Input */}
      <div className="input-section">
        <div className="content-box">
          <h4>Input</h4>
          <label className="input-label">Transcribed text</label>
          <textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="e.g. Take me to the nearest coffee shop..."
            rows={4}
            className="styled-textarea"
          />
          <div className="action-wrapper">
            <StyledButton
              btnText={loading ? "⏳ Parsing..." : "🧠 Parse Intent"}
              variant="contained"
              onClick={submitAction}
              disabled={!isAllowedToRun() || loading}
            />
            {loading && <span className="status-message">Analyzing with PathPilot AI...</span>}
          </div>
        </div>
      </div>

      {/* Output */}
      {showOutput && (
        <div className="output-section">
          <div className="content-box">
            <h4>Results</h4>
            {output?.error ? (
              <p style={{ color: "var(--error)", fontSize: 14 }}>{output.error}</p>
            ) : (
              renderResults(output)
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default ServiceUI;